
public class ProfessorNaoAtribuidoException extends NullPointerException {

}
