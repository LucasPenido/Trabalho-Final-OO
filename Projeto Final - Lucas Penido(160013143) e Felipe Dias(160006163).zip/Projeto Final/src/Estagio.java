import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Estagio extends Disciplina {
	private String localDeEstagio;
	private String responsavel;
	private Professor ProfessorResponsavel;

	public String toString() {
		StringBuilder bld = new StringBuilder();

		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}

		bld.append("Local de Estagio: ");
		bld.append(localDeEstagio + "\r\n");
		bld.append("Respons�vel: ");
		bld.append(responsavel + "\r\n");

		if (ProfessorResponsavel != null) {
			bld.append("Matr�cula FUB do Professor Respons�vel: ");
			bld.append(ProfessorResponsavel.getMatriculaFUB() + "\r\n");
		}

		if (localDeEstagio == null || responsavel == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}
		return bld.toString();
	}

	public void print() {
		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Disciplinas_Estagio.txt", true);
				PrintWriter pw = new PrintWriter(fw);

				pw.print("\r\nEstagio\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public Professor getProfessorResponsavel() {
		return ProfessorResponsavel;
	}

	public void setProfessorResponsavel(Professor professorResponsavel) {
		ProfessorResponsavel = professorResponsavel;
	}

	public String getLocalDeEstagio() {
		return localDeEstagio;
	}

	public void setLocalDeEstagio(String localDeEstagio) {
		this.localDeEstagio = localDeEstagio;
	}

	public String getResponsavel() {
		return responsavel;
	}

	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
}
