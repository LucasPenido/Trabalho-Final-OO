import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Auxiliar extends Professor {
	private String graduacao;
	private int anoGraduacao;

	public String toString() {
		StringBuilder bld = new StringBuilder();
		if (super.toString() == null) {
			return null;
		}else{
			bld.append(super.toString());
		}
		
		bld.append("Graduacao: ");
		bld.append(graduacao + "\r\n");
		bld.append("Ano Graduacao: ");
		bld.append(anoGraduacao + "\r\n");

		if (graduacao == null || anoGraduacao == 0) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}

		}
		return bld.toString();
	}
	
	public void print(){
		String bld = toString();
		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Professores.txt", true);
				PrintWriter pw = new PrintWriter(fw);
				
				pw.print("\r\nProfessor Auxiliar\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String getGraduacao() {
		return graduacao;
	}

	public void setGraduacao(String graduacao) {
		this.graduacao = graduacao;
	}

	public int getAnoGraduacao() {
		return anoGraduacao;
	}

	public void setAnoGraduacao(int anoGraduacao) {
		this.anoGraduacao = anoGraduacao;
	}

}
