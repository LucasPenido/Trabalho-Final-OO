
/*Lucas Penido Antunes - 16/0013143
 *Filipe Dias Soares Lima - 16/0006163 */

import java.io.File;
import java.util.Date;

public class Principal {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {

		File fileAlunos = new File("Lista de Alunos.txt");
		File fileProfessores = new File("Lista de Professores.txt");
		File fileDisciplinas = new File("Disciplinas_Estagio.txt");
		File fileTurma = new File("Turmas.txt");
		boolean existsAlunos = fileAlunos.exists();
		boolean existsProfessores = fileProfessores.exists();
		boolean existsDisciplinas = fileDisciplinas.exists();
		boolean existsTurma = fileTurma.exists();
		if (existsAlunos) {
			fileAlunos.delete();
		}
		if (existsProfessores) {
			fileProfessores.delete();
		}
		if (existsDisciplinas) {
			fileDisciplinas.delete();
		}
		if (existsTurma) {
			fileTurma.delete();
		}

		Professor p = new Professor();
		p.setMatriculaSiape(199999);
		p.setMatriculaFUB(1010);
		p.setFormacao("Eng");
		p.setSalario(19);
		p.print();

		/* INSANCIANDO PROFESSORES */

		Auxiliar aux = new Auxiliar();
		aux.setMatriculaSiape(613531);
		aux.setMatriculaFUB(9981);
		aux.setFormacao("Soft");
		aux.setSalario(500);
		aux.setGraduacao("Mat");
		aux.setAnoGraduacao(1987);
		aux.print();

		Assistente ass = new Assistente();
		ass.setMatriculaSiape(313131);
		ass.setMatriculaFUB(1010);
		ass.setFormacao("Mat");
		ass.setSalario(19);
		ass.setGraduacao("Quim");
		ass.setAnoGraduacao(1980);
		ass.setMestrado("Soft");
		ass.setAnoMestrado(2000);
		ass.setTituloDissertacao("Mat e Soft");
		ass.print();

		Adjunto adj = new Adjunto();
		adj.setMatriculaSiape(565665);
		adj.setMatriculaFUB(5912);
		adj.setFormacao("Port");
		adj.setSalario(1);
		adj.setGraduacao("Red");
		adj.setAnoGraduacao(1930);
		adj.setMestrado("Ling");
		adj.setAnoMestrado(2010);
		adj.setTituloDissertacao("Red");
		adj.setDoutorado("Lit");
		adj.setAnoDoutorado(2014);
		adj.setTituloTese("Lit e Red");
		adj.print();

		Associado assoc = new Associado();
		assoc.setMatriculaSiape(565665);
		assoc.setMatriculaFUB(5912);
		assoc.setFormacao("Port");
		assoc.setSalario(1);
		assoc.setGraduacao("Red");
		assoc.setAnoGraduacao(1930);
		assoc.setMestrado("Ling");
		assoc.setAnoMestrado(2010);
		assoc.setTituloDissertacao("Red");
		assoc.setDoutorado("Lit");
		assoc.setAnoDoutorado(2014);
		assoc.setTituloTese("Lit e Red");
		assoc.setAreaDePesquisa("Antiguidades");
		assoc.print();

		Titular titu = new Titular();
		titu.setMatriculaSiape(565665);
		titu.setMatriculaFUB(5912);
		titu.setFormacao("Port");
		titu.setSalario(1);
		titu.setGraduacao("Red");
		titu.setAnoGraduacao(1930);
		titu.setMestrado("Ling");
		titu.setAnoMestrado(2010);
		titu.setTituloDissertacao("Red");
		titu.setDoutorado("Lit");
		titu.setAnoDoutorado(2014);
		titu.setTituloTese("Lit e Red");
		titu.setAreaDePesquisa("Antiguidades");
		titu.setConcurso(new Date("10/07/2017"));
		titu.setDataDeAdmissao(new Date("05/15/2000"));
		titu.print();

		/* INSTANCIANDO ALUNOS */

		PosGraduacao a = new PosGraduacao();
		a.setMatricula(999999);
		a.setNome("Lucas");
		a.setSemestreIngresso("Primeiro");
		a.setSemestreQualificacao("Segundo");
		a.setAnoIngresso(2016);
		a.setProfessor(p);
		a.setDataDefesa(new Date("10/10/1000"));
		a.print();

		Especial esp = new Especial();
		esp.setMatricula(11111);
		esp.setNome("Gabriel");
		esp.setSemestreIngresso("Primeiro");
		esp.setAnoIngresso(2015);
		esp.setSemestreQualificacao("Segundo");
		esp.setProfessor(p);
		esp.setDataDefesa(new Date("05/02/2019"));
		esp.setTaxaPaga(true);
		esp.setSemestreCursado("Quinto");
		esp.print();

		Graduacao b = new Graduacao();
		b.setMatricula(888888);
		b.setNome("Filipe");
		b.setSemestreIngresso("Primeiro");
		b.setAnoIngresso(2016);
		b.setFormaIngresso("PAS");
		b.setCurso("Eng");
		b.setProvavelFormatura(new Date("11/11/1111"));
		b.print();

		/* INSTANCIANDO DISCIPLINAS */

		Estagio est = new Estagio();
		est.setNome("OO");
		est.setCargaHoraria(14);
		est.setLocalDeEstagio("BSB");
		est.setResponsavel("Andr�");
		est.setProfessorResponsavel(p);
		est.print();

		Disciplina dis = new Disciplina();
		dis.setCargaHoraria(12);
		dis.setNome("DAS");
		dis.print();

		/* INSTANCIANDO TURMAS */

		Turma turmaA = new Turma();
		turmaA.setCodigo(99999);
		turmaA.setHorario("14:00 - 16:00");
		turmaA.setDisciplina(dis);
		turmaA.setProfessor(p);
		turmaA.print();

		Turma turmaB = new Turma();
		turmaB.setCodigo(88888);
		turmaB.setHorario("10:00 - 12:00");
		turmaB.setDisciplina(dis);
		turmaB.setProfessor(p);
		turmaB.print();

	}
}
