import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Associado extends Adjunto {
	private String areaDePesquisa;

	public String toString() {
		StringBuilder bld = new StringBuilder();
		
		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}

		bld.append("Area de Pesquisa: ");
		bld.append(areaDePesquisa + "\r\n");

		if (areaDePesquisa == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}
		return bld.toString();
	}
	
	public void print(){
		
		String bld = toString();
		
		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Professores.txt", true);
				PrintWriter pw = new PrintWriter(fw);
				
				pw.print("\r\nProfessor Associado\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

	public String getAreaDePesquisa() {
		return areaDePesquisa;
	}

	public void setAreaDePesquisa(String areaDePesquisa) {
		this.areaDePesquisa = areaDePesquisa;
	}

}
