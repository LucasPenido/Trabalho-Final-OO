//Classe abstrata: não gera objetos
public abstract class Aluno {
	private int matricula;
	private String nome;
	private String semestreIngresso;
	private int anoIngresso;

	public String toString() {

		StringBuilder bld = new StringBuilder();
		bld.append("Matricula: ");
		bld.append(matricula + "\r\n");
		bld.append("Nome: ");
		bld.append(nome + "\r\n");
		bld.append("Semestre de Ingresso: ");
		bld.append(semestreIngresso + "\r\n");
		bld.append("Ano de Ingresso: ");
		bld.append(anoIngresso + "\r\n");

		if (matricula == 0 || nome == null || semestreIngresso == null || anoIngresso == 0) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}

		}
		return bld.toString();
	}

	public int getAnoIngresso() {
		return anoIngresso;
	}

	public void setAnoIngresso(int anoIngresso) {
		this.anoIngresso = anoIngresso;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSemestreIngresso() {
		return semestreIngresso;
	}

	public void setSemestreIngresso(String semestreIngresso) {
		this.semestreIngresso = semestreIngresso;
	}

}
