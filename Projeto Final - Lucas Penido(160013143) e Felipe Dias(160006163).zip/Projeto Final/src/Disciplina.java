import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Disciplina {
	private String nome;
	private int cargaHoraria;

	public String toString() {
		StringBuilder bld = new StringBuilder();

		bld.append("Nome: ");
		bld.append(nome + "\r\n");
		bld.append("Carga Horaria: ");
		bld.append(cargaHoraria + "\r\n");

		if (nome == null || cargaHoraria == 0) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}

		return bld.toString();
	}

	public void print() {
		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Disciplinas_Estagio.txt", true);
				PrintWriter pw = new PrintWriter(fw);

				pw.print("\r\nDisciplina\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCargaHoraria() {
		return cargaHoraria;
	}

	public void setCargaHoraria(int cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}

}
