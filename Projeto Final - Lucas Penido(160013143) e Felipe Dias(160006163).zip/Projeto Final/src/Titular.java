import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class Titular extends Associado {
	private Date concurso;
	private Date dataDeAdmissao;

	public String toString() {
		StringBuilder bld = new StringBuilder();
		
		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}

		bld.append("Concurso: ");
		bld.append(concurso + "\r\n");
		bld.append("Data de Admissao: ");
		bld.append(dataDeAdmissao + "\r\n");
		
		if (concurso == null || dataDeAdmissao == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}

		return bld.toString();
	}

	public void print() {

		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Professores.txt", true);
				PrintWriter pw = new PrintWriter(fw);
				
				pw.print("\r\nProfessor Titular\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public Date getConcurso() {
		return concurso;
	}

	public void setConcurso(Date concurso) {
		this.concurso = concurso;
	}

	public Date getDataDeAdmissao() {
		return dataDeAdmissao;
	}

	public void setDataDeAdmissao(Date dataDeAdmissao) {
		this.dataDeAdmissao = dataDeAdmissao;
	}

}
