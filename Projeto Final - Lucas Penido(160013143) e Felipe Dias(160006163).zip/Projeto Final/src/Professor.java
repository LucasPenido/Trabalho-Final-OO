import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Professor {
	private int matriculaSiape;
	private int matriculaFUB;
	private String formacao;
	private float salario;

	public String toString() {
		StringBuilder bld = new StringBuilder();
		
		bld.append("Matricula Siape: ");
		bld.append(matriculaSiape + "\r\n");
		bld.append("Matricula FUB: ");
		bld.append(matriculaFUB + "\r\n");
		bld.append("Forma��o: ");
		bld.append(formacao + "\r\n");
		bld.append("Salario: ");
		bld.append(salario + "\r\n");

		if (matriculaSiape == 0 || matriculaFUB == 0 || formacao == null || salario == 0) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}

		}
			return bld.toString();
	}

	public void print() {
		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Professores.txt", true);
				PrintWriter pw = new PrintWriter(fw);

				pw.print("\r\nProfessor\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public int getMatriculaSiape() {
		return matriculaSiape;
	}

	public void setMatriculaSiape(int matriculaSiape) {
		this.matriculaSiape = matriculaSiape;
	}

	public int getMatriculaFUB() {
		return matriculaFUB;
	}

	public void setMatriculaFUB(int matriculaFUB) {
		this.matriculaFUB = matriculaFUB;
	}

	public String getFormacao() {
		return formacao;
	}

	public void setFormacao(String formacao) {
		this.formacao = formacao;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}

}
