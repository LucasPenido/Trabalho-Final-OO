import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.swing.JOptionPane;

public class PosGraduacao extends Aluno {
	private String semestreQualificacao;
	private Date dataDefesa;
	private Professor professor;

	public String toString() {
		StringBuilder bld = new StringBuilder();

		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}

		bld.append("Semestre de Qualifica��o: ");
		bld.append(semestreQualificacao + "\r\n");
		bld.append("Data de Defesa: ");
		bld.append(dataDefesa + "\r\n");

		if (professor == null)
			try {
				throw new OrientadorNaoAtribuidoException();
			} catch (OrientadorNaoAtribuidoException e) {
				JOptionPane.showMessageDialog(null, "Aluno sem Professor Orientador:\n" + bld);
				return null;
			}
		else {
			bld.append("Matr�cula FUB do Professor Orientador: ");
			bld.append(professor.getMatriculaFUB() + "\r\n");
		}

		if (semestreQualificacao == null || dataDefesa == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}

		}

		return bld.toString();
	}

	public void print() {

		String bld = toString();

		if (bld != null) {

			try {
				FileWriter fw = new FileWriter("Lista de Alunos.txt", true);
				PrintWriter pw = new PrintWriter(fw);

				pw.print("\r\nAluno P�s Gradua��o\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public String getSemestreQualificacao() {
		return semestreQualificacao;
	}

	public void setSemestreQualificacao(String semestreQualificacao) {
		this.semestreQualificacao = semestreQualificacao;
	}

	public Date getDataDefesa() {
		return dataDefesa;
	}

	public void setDataDefesa(Date dataDefesa) {
		this.dataDefesa = dataDefesa;
	}
}
