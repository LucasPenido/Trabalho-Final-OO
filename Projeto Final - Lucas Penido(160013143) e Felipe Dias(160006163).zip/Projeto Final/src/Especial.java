import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Especial extends PosGraduacao {
	private Boolean taxaPaga ;
	private String semestreCursado;

	public String toString() {
		StringBuilder bld = new StringBuilder();
		
		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}
		
		bld.append("Taxa Paga: ");
		bld.append(taxaPaga + "\r\n");
		bld.append("Semestre Cursado: ");
		bld.append(semestreCursado + "\r\n");

		if (semestreCursado == null || taxaPaga == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}

		}

		return bld.toString();
	}
	
	public void print(){
		
		String bld = toString();
		
		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Alunos.txt", true);
				PrintWriter pw = new PrintWriter(fw);
				
				pw.print("\r\nAluno Especial\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} 
	}


	public Boolean getTaxaPaga() {
		return taxaPaga;
	}

	public void setTaxaPaga(Boolean taxaPaga) {
		this.taxaPaga = taxaPaga;
	}

	public String getSemestreCursado() {
		return semestreCursado;
	}

	public void setSemestreCursado(String semestreCursado) {
		this.semestreCursado = semestreCursado;
	}
}
