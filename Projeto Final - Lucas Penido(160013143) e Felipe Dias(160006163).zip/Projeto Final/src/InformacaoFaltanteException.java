
@SuppressWarnings("serial")
public class InformacaoFaltanteException extends Exception {
	public InformacaoFaltanteException(){
		System.out.println("Erro na Classe: \n");
		printStackTrace();
	}
}
