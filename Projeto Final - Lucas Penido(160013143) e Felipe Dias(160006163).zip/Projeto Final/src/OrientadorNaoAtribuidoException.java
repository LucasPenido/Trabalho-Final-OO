import javax.swing.JOptionPane;

public class OrientadorNaoAtribuidoException extends NullPointerException {
	

}
