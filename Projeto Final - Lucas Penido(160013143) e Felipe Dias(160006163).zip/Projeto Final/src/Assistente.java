import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Assistente extends Auxiliar {
	private String mestrado;
	private int anoMestrado;
	private String tituloDissertacao;

	public String toString() {
		StringBuilder bld = new StringBuilder();

		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}

		bld.append("Mestrado: ");
		bld.append(mestrado + "\r\n");
		bld.append("Ano Mestrado: ");
		bld.append(anoMestrado + "\r\n");
		bld.append("T�tulo de Disserta��o: ");
		bld.append(tituloDissertacao + "\r\n");

		if (mestrado == null || anoMestrado == 0 || tituloDissertacao == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}
		return bld.toString();
	}

	public void print() {

		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Professores.txt", true);
				PrintWriter pw = new PrintWriter(fw);

				pw.print("\r\nProfessor Assistente\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String getMestrado() {
		return mestrado;
	}

	public void setMestrado(String mestrado) {
		this.mestrado = mestrado;
	}

	public int getAnoMestrado() {
		return anoMestrado;
	}

	public void setAnoMestrado(int anoMestrado) {
		this.anoMestrado = anoMestrado;
	}

	public String getTituloDissertacao() {
		return tituloDissertacao;
	}

	public void setTituloDissertacao(String tituloDissertacao) {
		this.tituloDissertacao = tituloDissertacao;
	}

}
