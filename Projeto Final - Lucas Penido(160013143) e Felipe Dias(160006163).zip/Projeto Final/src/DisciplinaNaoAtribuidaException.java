
public class DisciplinaNaoAtribuidaException extends NullPointerException {

}
