import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Adjunto extends Assistente {
	private String doutorado;
	private int anoDoutorado;
	private String tituloTese;

	public String toString() {
		StringBuilder bld = new StringBuilder();

		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}

		bld.append("Doutorado: ");
		bld.append(doutorado + "\r\n");
		bld.append("Ano Doutorado: ");
		bld.append(anoDoutorado + "\r\n");
		bld.append("Titulo Tese: ");
		bld.append(tituloTese + "\r\n");

		if (doutorado == null || anoDoutorado == 0 || tituloTese == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}

		return bld.toString();
	}

	public void print() {

		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Professores.txt", true);
				PrintWriter pw = new PrintWriter(fw);

				pw.print("\r\nProfessor Adjunto\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String getDoutorado() {
		return doutorado;
	}

	public void setDoutorado(String doutorado) {
		this.doutorado = doutorado;
	}

	public int getAnoDoutorado() {
		return anoDoutorado;
	}

	public void setAnoDoutorado(int anoDoutorado) {
		this.anoDoutorado = anoDoutorado;
	}

	public String getTituloTese() {
		return tituloTese;
	}

	public void setTituloTese(String tituloTese) {
		this.tituloTese = tituloTese;
	}

}
