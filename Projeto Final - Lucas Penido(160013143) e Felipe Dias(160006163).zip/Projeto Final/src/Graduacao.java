import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class Graduacao extends Aluno {
	private String formaIngresso;
	private String curso;
	private Date provavelFormatura;

	public String toString() {
		StringBuilder bld = new StringBuilder();

		if (super.toString() == null) {
			return null;
		} else {
			bld.append(super.toString());
		}
		
		bld.append("Forma Ingresso: ");
		bld.append(formaIngresso + "\r\n");
		bld.append("Curso: ");
		bld.append(curso + "\r\n");
		bld.append("Provavel Formatura: ");
		bld.append(provavelFormatura + "\r\n");

		if (formaIngresso == null || curso == null || provavelFormatura == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}

		return bld.toString();
	}

	public void print() {

		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Lista de Alunos.txt", true);
				PrintWriter pw = new PrintWriter(fw);

				pw.print("\r\nAluno Gradua��o\r\n");
				pw.print(bld);
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String getFormaIngresso() {
		return formaIngresso;
	}

	public void setFormaIngresso(String formaIngresso) {
		this.formaIngresso = formaIngresso;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public Date getProvavelFormatura() {
		return provavelFormatura;
	}

	public void setProvavelFormatura(Date provavelFormatura) {
		this.provavelFormatura = provavelFormatura;
	}

}
