import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

public class Turma {
	private int codigo;
	private String horario;
	private Professor professor;
	private Disciplina disciplina;

	public String toString() {
		StringBuilder bld = new StringBuilder();

		bld.append("Codigo: ");
		bld.append(codigo + "\r\n");
		bld.append("Horario: ");
		bld.append(horario + "\r\n");

		if (professor == null && disciplina == null) {
			try {
				throw new ProfessorNaoAtribuidoException();
			} catch (ProfessorNaoAtribuidoException e) {
				JOptionPane.showMessageDialog(null, "Turma sem Professor Associado:\n" + bld);
			}
			try {
				throw new DisciplinaNaoAtribuidaException();
			} catch (DisciplinaNaoAtribuidaException e) {
				JOptionPane.showMessageDialog(null, "Turma sem Disciplina Associada:\n" + bld);
				return null;
			}
		} else if (professor == null) {
			try {
				throw new ProfessorNaoAtribuidoException();
			} catch (ProfessorNaoAtribuidoException e) {
				JOptionPane.showMessageDialog(null, "Turma sem Professor Associado:\n" + bld);
				return null;
			}
		}

		else if (disciplina == null) {
			try {
				throw new DisciplinaNaoAtribuidaException();
			} catch (DisciplinaNaoAtribuidaException e) {
				JOptionPane.showMessageDialog(null, "Turma sem Disciplina Associada:\n" + bld);
				return null;
			}
		} else {
			bld.append("Disciplina Associada: ");
			bld.append(disciplina.getNome() + "\r\n");
			bld.append("Matr�cula FUB do Professor Respons�vel: ");
			bld.append(professor.getMatriculaFUB() + "\r\n");
		}

		if (codigo == 0 || horario == null) {
			try {
				throw new InformacaoFaltanteException();
			} catch (InformacaoFaltanteException e) {
				e.printStackTrace();
				return null;
			}
		}
		return bld.toString();
	}

	public void print() {
		String bld = toString();

		if (bld != null) {
			try {
				FileWriter fw = new FileWriter("Turmas.txt", true);
				PrintWriter pw = new PrintWriter(fw);
				
				pw.print("\r\nTurma\r\n");
				pw.print(bld);
				pw.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public Professor getProfessor() {
		return professor;
	}

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	public Disciplina getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
}
